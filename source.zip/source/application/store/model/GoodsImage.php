<?php

namespace app\store\model;

use app\common\model\GoodsImage as GoodsImageModel;

/**
 * 商品图片模型
 * Class GoodsImage
 * @package app\store\model
 */
class GoodsImage extends GoodsImageModel
{
}
