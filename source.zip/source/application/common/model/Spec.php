<?php

namespace app\common\model;

/**
 * 规格/属性(组)模型
 * Class Spec
 * @package app\common\model
 */
class Spec extends BaseModel
{
    protected $name = 'spec';
    protected $updateTime = false;

}
